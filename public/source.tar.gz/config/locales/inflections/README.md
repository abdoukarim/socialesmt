This directory contains the definitions for the [i18n-inflector gem](https://github.com/siefca/i18n-inflector).
Look at the documentation there and our [contributing translations](https://github.com/diaspora/diaspora/wiki/How-to-contribute-translations) wiki page for more informations
and how to contribute.
