# Please read the [translation guide](https://github.com/diaspora/diaspora/wiki/How-to-contribute-translations) before contributing!
